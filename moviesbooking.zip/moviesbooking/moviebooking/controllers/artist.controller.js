const Artist = require("../models/artist.model");

exports.findAllArtists = async (req, res) => {
  try {
    const artists = await Artist.find();
    res.json(artists);
  } catch (error) {
    res.status(500).json({ message: "Error fetching artists", error: error.message });
  }
};
