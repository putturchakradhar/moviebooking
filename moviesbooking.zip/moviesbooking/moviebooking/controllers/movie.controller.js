const Movie = require("../models/movie.model");

exports.findAllMovies = async (req, res) => {
  try {
    let query = {};
    if (req.query.status) {
      query.status = req.query.status.toUpperCase(); // PUBLISHED or RELEASED
    }
    if (req.query.title) {
      query.title = new RegExp(req.query.title, "i"); // Case-insensitive search
    }
    if (req.query.genres) {
      query.genres = { $in: req.query.genres.split(",") }; // Match any genre
    }
    if (req.query.artists) {
      query.artists = { $in: req.query.artists.split(",") }; // Match any artist
    }
    if (req.query.start_date && req.query.end_date) {
      query.releaseDate = {
        $gte: new Date(req.query.start_date),
        $lte: new Date(req.query.end_date),
      };
    }

    const movies = await Movie.find(query);
    res.json(movies);
  } catch (error) {
    res.status(500).json({ message: "Error fetching movies", error: error.message });
  }
};

exports.findByTitle = async (req, res) => {
  try {
      const movie = await Movie.findOne({ movieid: Number(req.params.title) }); // Convert to Number
      if (!movie) {
          return res.status(404).json({ message: "Movie not found" });
      }
      res.json(movie);
  } catch (error) {
      res.status(500).json({ message: "Error fetching movie details", error: error.message });
  }
};




exports.findShows = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.movieId).populate("shows");
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.json(movie.shows);
  } catch (error) {
    res.status(500).json({ message: "Error fetching shows", error: error.message });
  }
};
