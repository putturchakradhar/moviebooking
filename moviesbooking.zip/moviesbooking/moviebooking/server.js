const express = require("express");
const mongoose = require("mongoose");

const movieRoutes = require("./routes/movie.routes");
const userRoutes = require("./routes/user.routes");
const artistRoutes = require("./routes/artist.routes");
const genreRoutes = require("./routes/genre.routes");

const app = express();
const port = process.env.PORT || 8085; // Define port before usage

app.use(express.json()); // Middleware to parse JSON requests

// API Routes (Define them first)
app.use("/api/movies", movieRoutes);
app.use("/api/users", userRoutes);
app.use("/api/artists", artistRoutes);
app.use("/api/genres", genreRoutes);

// Root Route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to Upgrad Movie Booking Application Development." });
});

// Handle unknown routes (404)
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// MongoDB Connection
const mongoURI = "mongodb://127.0.0.1:27017/moviesdb"; // Ensure database name is correct

mongoose
  .connect(mongoURI)
  .then(() => {
    console.log("✅ Connected to MongoDB");

    // Start the server only after MongoDB is connected
    app.listen(port, () => {
      console.log(`🚀 Server running at http://localhost:${port}/api`);
    });
  })
  .catch((err) => {
    console.error("❌ Cannot connect to MongoDB!", err);
    process.exit(1);
  });

module.exports = app; // Export app for testing or external usage
