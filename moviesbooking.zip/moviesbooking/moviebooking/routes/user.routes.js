const express = require("express");
const router = express.Router();
const userController = require("../controllers/user.controller");

// Define authentication routes
router.post("/auth/signup", userController.signUp);
router.post("/auth/login", userController.login);
router.post("/auth/logout", userController.logout);

module.exports = router;
