const express = require("express");
const router = express.Router();
const movieController = require("../controllers/movie.controller"); // Ensure this path is correct

router.get("/movies", movieController.findAllMovies);
router.get('/movies/:title', movieController.findByTitle); 
router.get("/movies/:movieId/shows", movieController.findShows);

module.exports = router;
